import logo from './logo.svg';
import './App.css';
import Weather from './component/Weather';
import SearchWeather from './component/SearchWeather';

function App() {
  return (
    <div className="App">
    <Weather/>
    </div>
  );
}

export default App;
